Tent House Hisab Android Project
Android Studio में project खोलें → Gradle Sync → Build > Build APK(s).
APK: app/build/outputs/apk/debug/app-debug.apk
